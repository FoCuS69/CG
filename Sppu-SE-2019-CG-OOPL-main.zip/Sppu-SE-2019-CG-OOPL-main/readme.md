**To run NORMAL C++ Code (OOP) :**

1) g++ filename.cpp
2) ./a.out


**To run normal GRAPHICS Code :**

1) g++ filename.cpp -lgraph
2) ./a.out


**To run OPENGL Code :**

1) g++ filename.cpp -lGL -lGLU -lglut
2) ./a.out


*NOTE : if g++ is NOT working, try replacing with gcc.*
*NOTE : -o flag followed by outputfilename.out can be used after compiling command for diffrent output file, but will change the output file name required while running also.*